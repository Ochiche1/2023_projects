package com.integrator.equiWeb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EquiWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
