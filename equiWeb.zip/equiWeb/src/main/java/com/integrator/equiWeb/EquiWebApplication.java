package com.integrator.equiWeb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EquiWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(EquiWebApplication.class, args);
	}

}
